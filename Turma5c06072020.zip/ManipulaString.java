import javax.swing.JOptionPane;

class ManipulaString{

public static void main(String args[]){

String email=JOptionPane.showInputDialog("Digite o email");
System.out.println("Minúsculo: " + email.toLowerCase());
System.out.println("Maiúsculo: " + email.toUpperCase());
System.out.println("Qtde Caracteres: " + email.length());
System.out.println("Posição do @: " + email.indexOf("@")); 
System.out.println("3 primeiros caracteres: " + email.substring(0,3));
System.out.println("Do 3º em diante: " + email.substring(2));
// Desafio: exibam todos os caracteres até o @
System.out.println("Usuario:" + email.substring(0, email.indexOf("@")));
// Exibir o servidor do email
System.out.println("Servidor:" + email.substring(email.indexOf("@")+1));
System.out.println("É igual a teste@teste.com?" + email.equals("teste@teste.com"));


}

}