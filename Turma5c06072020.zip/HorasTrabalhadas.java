import java.util.Scanner;
class HorasTrabalhadas{
public static void main(String args[]){
Scanner teclado = new Scanner(System.in);
System.out.println("Digite o nome do colaborador: ");
String colaborador = teclado.next();
System.out.println("Digite o total de horas que você trabalhou neste mes:");
int horasTrabalhadas = teclado.nextInt();
System.out.println("Digite o valor da hora");
float valorHora = teclado.nextFloat(); 
int qtdeHorasExtras = horasTrabalhadas - 160;
float valorHoraExtra = valorHora * 1.5f;
float totalHorasExtras = qtdeHorasExtras * valorHoraExtra;
System.out.println("Qtde de Horas Extras...........: " + qtdeHorasExtras);
System.out.println("Valor de cada hora extra.......: " + valorHoraExtra);
System.out.println("Total a receber de horas extras: " + totalHorasExtras);
}
}


